#include <QApplication>
#include"form.h"
#include<ui_form.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
 Form *f1=new Form();
    f1->show();

    return a.exec();
}

