#include "form.h"
#include "ui_form.h"
#include<QString>
#include<qmessagebox.h>
#include<QTime>
#include <qpushbutton.h>
#include<assert.h>


int question_paper_clicked;
question question_paper[total_Q_paper] ;

QString IntToQstring(int source) ;
QTime systemtime;
QByteArray buffer_read;
bool buffer_read_bool;
Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    this->setWindowTitle("login window");
    QDesktopWidget dw;
    int x=dw.width()*1;
    int y=dw.height()*1;
    char *sptr=(char *)malloc(20);

//    ui->frame->move(QApplication::desktop()->screen()->rect().center() - ui->frame->rect().center());
x=320;
y=220;int w,z;
x=QApplication::desktop()->screen()->rect().left();
y=QApplication::desktop()->screen()->rect().top();
w=QApplication::desktop()->screen()->rect().right();
z=QApplication::desktop()->screen()->rect().bottom();
int i;
    for( i=0;i<total_Q_paper;i++)
    {
     question_paper[i].q_object = new QToolButton(this);
     question_paper[i].q_object->setCheckable(true);
     if(i%3== 0 )
     {
         x=x+200;y=150;

     }
     question_paper[i].q_object->setGeometry(x,y,w,z);
     question_paper[i].q_object->setFixedSize(150,100);
     question_paper[i].q_object->setCheckable(true);
     y=y+200;

         sprintf(sptr,"MOCK TEST %d",i+1);
          question_paper[i].q_object->setText(sptr);

          connect(question_paper[i].q_object, SIGNAL(clicked(bool)), this, SLOT(select_qpaper()));
    }

free(sptr);

}
question::~question()
{

}
Form::~Form()
{
    delete ui;
}
char IP_ADDR[50];
int PORT_NO;
QString USN_NO;
QString NAME;
QString EMAIL_ID;
QString username;
QString password;

void Form::select_qpaper()
{
    for(int i=0;i<total_Q_paper;i++)
    {


   if( question_paper[i].q_object->isChecked())
   {
    question_paper_clicked=i+1;
    question_paper[i].q_object->setChecked(false);
    break;
   }

    }
//     question_paper[question_paper_clicked-1].q_object->setStyleSheet("background-color: rgb(85, 170, 0);");
//      question_paper[question_paper_clicked-1].seen=true;
     w=new MainWindow();
           w->show();
}




