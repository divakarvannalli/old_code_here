#include "mainwindow.h"
#include <QApplication>
#include<assert.h>
#include<qtableview.h>

void add_answers(QString path);
void create_table(QString path_1 );


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   MainWindow w;
    QString path="/home/user/Desktop/database/correct_answer_table";
    create_table(path);
  add_answers(path);



    QSqlDatabase *answer_table;
  QSqlDatabase  answer_table_=QSqlDatabase::addDatabase("QSQLITE");
  answer_table=& answer_table_;
  answer_table->setDatabaseName(path);
    if (!answer_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }

    QSqlQuery query(*answer_table);
    query.exec("SELECT* FROM answer_table");
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);

    QTableView *view = new QTableView(&w);
    view->setModel(model);

    w.setCentralWidget(view);

 w.show();
return a.exec();
}

void create_table(QString path_1 )
{
    QString path=path_1;
    QSqlDatabase *answer_table;
  QSqlDatabase  answer_table_=QSqlDatabase::addDatabase("QSQLITE");
  answer_table=& answer_table_;
  answer_table->setDatabaseName(path);
    if (!answer_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
    QSqlQuery query_answers(*answer_table);
    QString quest = "create table IF NOT EXISTS  answer_table(id integer primary key";
    for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
    {
   QString quest_ = ",answer"+QString::number(i)+"  varchar(300)" ;
   quest = quest + quest_;
    }
    quest = quest +")";
    qDebug()<<quest;
  bool  k=query_answers.exec(quest);
  assert(k!=false);
for(int j=1;j<=TOTAL_NO_OF_Q_PAPER;j++)
{
    k= query_answers.exec("INSERT INTO answer_table(answer1) VALUES(0)");
    qDebug()<<query_answers.lastError();
    assert(k!=false);
}
query_answers.finish();
}


void add_answers(QString path)
{
    for( int q_paper_count=1;q_paper_count<=TOTAL_NO_OF_Q_PAPER;q_paper_count++)
 {
  QSqlDatabase *answer_table;
  QSqlDatabase  answer_table_=QSqlDatabase::addDatabase("QSQLITE");
  answer_table=& answer_table_;
  answer_table->setDatabaseName(path);
    if (!answer_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
     QSqlQuery query_answers(*answer_table);
    FILE *answer_fptr;
 char* ch,*ch2;

  ch=(char*)malloc(256);
  ch2=(char*)malloc(18);
    char line[256]={0};
    int Quest_count=1;
    strcpy(ch,answer_file_path_thread);

    sprintf(ch2,"%d.txt\0",q_paper_count);
    strcat(ch,ch2);
    answer_fptr=fopen(ch,"r");
    free(ch);
    free(ch2);
    if(answer_fptr== NULL)
    {
        qDebug()<<"cant open question file thus exiting ";
       exit(1);
    }
    QString temp;

      while ((fgets(line, sizeof line, answer_fptr) != NULL)&& (Quest_count<=200)) /* read a line */
    {

          if(temp.sprintf(line) == "\n")
              continue;

        QString qstn,query_str;
        qstn.sprintf(line);
       query_str = "UPDATE answer_table SET answer"+QString::number(Quest_count)+" = \""+qstn +"\" WHERE id=:id";

        bool k =  query_answers.prepare(query_str);
        qDebug()<<query_answers.lastError().text();
        assert(k!=false);
        query_answers.bindValue(":id", q_paper_count);
         k =  query_answers.exec();
        qDebug()<<"--------->"<<k+"   "<<query_answers.lastError().text() ;
     assert(k!=false);
     Quest_count++;
     }
      fclose(answer_fptr);
}

}
