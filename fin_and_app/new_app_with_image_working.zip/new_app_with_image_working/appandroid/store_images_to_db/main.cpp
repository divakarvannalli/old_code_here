#include "mainwindow.h"
#include <QApplication>
#include<assert.h>
#include<qtableview.h>

void add_images_to_DB(QString path);
void create_table(QString path_1 );


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   MainWindow w;
    QString path="/home/user/Desktop/database/images_of_qp_db";
    create_table(path);
  add_images_to_DB(path);

  QSqlDatabase *image_table;
  QSqlDatabase  image_table_=QSqlDatabase::addDatabase("QSQLITE");
  image_table=& image_table_;
  image_table->setDatabaseName(path);
    if (!image_table->open())
    {
       qDebug() << "Error: connection with database fail:image_table";
    }

    QSqlQuery query(*image_table);
    query.exec("SELECT* FROM image_table");
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);

    QTableView *view = new QTableView(&w);
    view->setModel(model);

    w.setCentralWidget(view);

    w.show();
    return a.exec();
}

void create_table(QString path_1 )
{
    QString path=path_1;
    QSqlDatabase *image_table;
  QSqlDatabase  image_table_=QSqlDatabase::addDatabase("QSQLITE");
  image_table=& image_table_;
  image_table->setDatabaseName(path);
    if (!image_table->open())
    {
       qDebug() << "Error: connection with database fail:image_table ";
    }
    QSqlQuery query_image_table(*image_table);
    QString image_string = "create table IF NOT EXISTS  image_table(id integer primary key";
    for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
    {
   QString image_string_ = ",image"+QString::number(i)+"  varchar(300)" ;
   image_string = image_string +image_string_;
    }
    image_string = image_string +")";
    qDebug()<<image_string;
  bool  k=query_image_table.exec(image_string);
  assert(k!=false);
for(int j=1;j<=TOTAL_NO_OF_Q_PAPER;j++)
{
    k= query_image_table.exec("INSERT INTO image_table(image1) VALUES(0)");
     assert(k!=false);
}
query_image_table.finish();
}


void add_images_to_DB(QString path)
{
    for( int q_paper_count=1;q_paper_count<=TOTAL_NO_OF_Q_PAPER;q_paper_count++)
 {
  QSqlDatabase *image_table;
  QSqlDatabase  image_table_=QSqlDatabase::addDatabase("QSQLITE");
  image_table=& image_table_;
  image_table->setDatabaseName(path);
    if (!image_table->open())
    {
       qDebug() << "Error: connection with database fail:image_table";
    }
     QSqlQuery query_image_table(*image_table);
    FILE *images_file_fptr;
 char* ch,*ch2;

  ch=(char*)malloc(256);
  ch2=(char*)malloc(18);
    char line[256]={0};
    int Quest_count=1;
    strcpy(ch,images_file_path_thread);

    sprintf(ch2,"%d.txt\0",q_paper_count);
    strcat(ch,ch2);
   images_file_fptr=fopen(ch,"r");
    free(ch);
    free(ch2);
    if(images_file_fptr== NULL)
    {
        qDebug()<<"cant open description file thus exiting ";
       exit(1);
    }
    QString temp;

      while ((fgets(line, sizeof line, images_file_fptr) != NULL)&& (Quest_count<=200)) /* read a line */
    {

          if(temp.sprintf(line) == "\n")
              continue;

        QString qstn,query_str;
        qstn.sprintf(line);
       query_str = "UPDATE image_table SET image"+QString::number(Quest_count)+" = \""+qstn +"\" WHERE id=:id";

        bool k =  query_image_table.prepare(query_str);
        qDebug()<<query_image_table.lastError().text();
        assert(k!=false);
        query_image_table.bindValue(":id", q_paper_count);
         k =  query_image_table.exec();
        qDebug()<<"--------->"<<k+"   "<<query_image_table.lastError().text() ;
     assert(k!=false);
     Quest_count++;
     }
      fclose(images_file_fptr);
}

}
