#include "mainwindow.h"
#include <QApplication>
#include<assert.h>
#include<qtableview.h>

void add_description(QString path);
void create_table(QString path_1 );


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   MainWindow w;
    QString path="/home/user/Desktop/database/question_description_table";
    create_table(path);
  add_description(path);

  QSqlDatabase *description_table;
  QSqlDatabase  description_table_=QSqlDatabase::addDatabase("QSQLITE");
  description_table=& description_table_;
  description_table->setDatabaseName(path);
    if (!description_table->open())
    {
       qDebug() << "Error: connection with database fail:description table";
    }

    QSqlQuery query(*description_table);
    query.exec("SELECT* FROM description_table");
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);

    QTableView *view = new QTableView(&w);
    view->setModel(model);

    w.setCentralWidget(view);

    w.show();
    return a.exec();
}

void create_table(QString path_1 )
{
    QString path=path_1;
    QSqlDatabase *description_table;
  QSqlDatabase  description_table_=QSqlDatabase::addDatabase("QSQLITE");
  description_table=& description_table_;
  description_table->setDatabaseName(path);
    if (!description_table->open())
    {
       qDebug() << "Error: connection with database fail:description table";
    }
    QSqlQuery query_description(*description_table);
    QString description = "create table IF NOT EXISTS  description_table(id integer primary key";
    for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
    {
   QString description_ = ",description"+QString::number(i)+"  varchar(300)" ;
   description = description + description_;
    }
    description = description +")";
    qDebug()<<description;
  bool  k=query_description.exec(description);
  assert(k!=false);
for(int j=1;j<=TOTAL_NO_OF_Q_PAPER;j++)
{
    k= query_description.exec("INSERT INTO description_table(description1) VALUES(0)");
     assert(k!=false);
}
query_description.finish();
}


void add_description(QString path)
{
    for( int q_paper_count=1;q_paper_count<=TOTAL_NO_OF_Q_PAPER;q_paper_count++)
 {
  QSqlDatabase *description_table;
  QSqlDatabase  description_table_=QSqlDatabase::addDatabase("QSQLITE");
  description_table=& description_table_;
  description_table->setDatabaseName(path);
    if (!description_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
     QSqlQuery query_description(*description_table);
    FILE *description_fptr;
 char* ch,*ch2;

  ch=(char*)malloc(256);
  ch2=(char*)malloc(18);
    char line[256]={0};
    int Quest_count=1;
    strcpy(ch,description_file_path_thread);

    sprintf(ch2,"%d.txt\0",q_paper_count);
    strcat(ch,ch2);
   description_fptr=fopen(ch,"r");
    free(ch);
    free(ch2);
    if(description_fptr== NULL)
    {
        qDebug()<<"cant open description file thus exiting ";
       exit(1);
    }
    QString temp;

      while ((fgets(line, sizeof line, description_fptr) != NULL)&& (Quest_count<=200)) /* read a line */
    {

          if(temp.sprintf(line) == "\n")
              continue;

        QString qstn,query_str;
        qstn.sprintf(line);
       query_str = "UPDATE description_table SET description"+QString::number(Quest_count)+" = \""+qstn +"\" WHERE id=:id";

        bool k =  query_description.prepare(query_str);
        qDebug()<<query_description.lastError().text();
        assert(k!=false);
        query_description.bindValue(":id", q_paper_count);
         k =  query_description.exec();
        qDebug()<<"--------->"<<k+"   "<<query_description.lastError().text() ;
     assert(k!=false);
     Quest_count++;
     }
      fclose(description_fptr);
}

}
