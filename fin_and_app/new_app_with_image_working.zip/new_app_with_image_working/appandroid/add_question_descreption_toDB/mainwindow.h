#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtSql>
#include <QMainWindow>

#define TOTAL_NO_OF_QUESTIONS 200
#define TOTAL_NO_OF_Q_PAPER 3

#define  description_file_path_thread "/home/user/appandroid/description/description"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
