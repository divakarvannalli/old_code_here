#ifndef COMMON_H
#define COMMON_H


//attended each question
int attended_section_1_question;
int attended_section_2_question;
int attended_section_3_question;
int attended_section_4_question;

int not_answered_resoning,wrong_answered_resoning,
not_answered_data_analysis,wrong_answered_data_analysis,
not_answered_GK,wrong_answered_GK,
not_answered_english,wrong_answered_english;

double overall_score;


int correct_reasoning;
int correct_data_analysis;
int correct_GK;
int correct_english;

double   Reasoning_marks ;
double    data_analysis_marks ;
double   gk_marks;
double      english_marks;

float neg_factor=0.25;
#endif // COMMON_H
