#include "mainwindow.h"
#include <QApplication>
#include<assert.h>
#include<qtableview.h>



char * radio_button(char * arr ,char * ch)
{


          int  i=0;
if(ch[i] == '\n')
{
 arr[i]=ch[i];

}
else
{
             while(ch[i]!=';')
             {

                 arr[i]=ch[i];
                 i++;

             }
 }
             arr[i+1]='\0';
            ch=ch+i;

            return ch;
}




QSqlDatabase *  create_table(QString path_1 ,int select)
{
    QString path=path_1;

    QSqlDatabase *option_table;
  QSqlDatabase  option_table_=QSqlDatabase::addDatabase("QSQLITE");
  option_table=& option_table_;
  option_table->setDatabaseName(path);
    if (!option_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
QSqlQuery query_option(*option_table);
QString qs = "create table IF NOT EXISTS option_table (id integer primary key";
//for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
{
for(int j=1;j<=TOTAL_NO_OF_QUESTIONS*NO_OF_OPTIONS;j++)
{
    qs=qs+",";
qs = qs+" option"+QString::number(j)+" varchar(100)";
}
}
qs=qs+")";
//qDebug()<<qs;
bool k = query_option.exec(qs);
      if(k!=true)
      {

        qDebug()<<query_option.lastError();
        assert(0);

      }
for(int i=0;i<TOTAL_NO_OF_Q_PAPER;i++)
{
     k = query_option.exec("INSERT INTO option_table(option1) VALUES (0)");
     if(k!=true)
     {
         qDebug()<<query_option.lastError();
         assert(0);
     }
}
query_option.finish();
}

void add_options(int question_paper_clicked,QString path)
{
    for(int q_paper=1;q_paper<=TOTAL_NO_OF_Q_PAPER;q_paper++)
    {
    QSqlDatabase *option_table;
    QSqlDatabase  option_table_=QSqlDatabase::addDatabase("QSQLITE");
    option_table=& option_table_;
    option_table->setDatabaseName(path);
      if (!option_table->open())
      {
         qDebug() << "Error: connection with database fail:question table";
      }
       QSqlQuery query_option(*option_table);
      FILE *option_fptr;
   char* ch,*ch2;

    ch=(char*)malloc(256);
    ch2=(char*)malloc(18);
      char line[256]={0};
      int Quest_count=1;
      strcpy(ch,options_file_path_thread);

      sprintf(ch2,"%d.txt\0",q_paper);
      strcat(ch,ch2);
      option_fptr=fopen(ch,"r");
      free(ch);
      free(ch2);
      if(option_fptr== NULL)
      {
          qDebug()<<"cant open question file thus exiting ";
         exit(1);
      }
int q_num=1;
QString temp;


         while (fgets(line, sizeof line, option_fptr) != NULL) /* read a line */
        {
             if(temp.sprintf(line) == "\n")
                 continue;
             QString qstn1,qstn2,qstn3,qstn4,qstn5,qstn_query;
             char arr[5][15]={0};

             ch=radio_button(arr[0],line+2);
             qstn1.sprintf(arr[0]);

              ch=radio_button(arr[1],ch+1);
              qstn2.sprintf(arr[1]);

               ch=radio_button(arr[2],ch+1);
               qstn3.sprintf(arr[2]);

                ch=radio_button(arr[3],ch+1);
                qstn4.sprintf(arr[3]);

                ch=radio_button(arr[4],ch+1);
                 qstn5.sprintf(arr[4]);
qstn_query = "UPDATE option_table SET option"+QString::number(q_num)+" = \""+qstn1+"\", option"+QString::number(q_num+1)+" = \""+qstn2+"\", option"+QString::number(q_num+2)+" = \""+qstn3+"\", option"+QString::number(q_num+3)+ " = \""+qstn4+"\", option"+QString::number(q_num+4)+ "= \""+qstn5+"\" WHERE rowid=:id";
    qDebug()<<qstn_query<<"\n";
            bool k = query_option.prepare(qstn_query);
            if(k!=true)
            {
            qDebug()<<"--------->"<<k+"   "<<query_option.lastError().text() ;
            assert(0);
            }
            query_option.bindValue(":id",q_paper);
            k =  query_option.exec();
            if(k!=true)
             {
            qDebug()<<"--------->"<<k+"   "<<query_option.lastError().text() ;
            assert(0);
             }
            q_num = q_num+5;

     }
 query_option.finish();

}

}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;

  QString  path="/home/user/Desktop/database/option_table";
  QSqlDatabase *options_table;
   options_table=create_table(path,2);
   add_options(1,path);



    QSqlDatabase *option_table;
  QSqlDatabase  option_table_=QSqlDatabase::addDatabase("QSQLITE");
  option_table=& option_table_;
  option_table->setDatabaseName(path);
    if (!option_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }

    QSqlQuery query(*option_table);
    query.exec("SELECT* FROM option_table");
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);

    QTableView *view = new QTableView(&w);
    view->setModel(model);

    w.setCentralWidget(view);

    w.show();
    return a.exec();




}
#if 0
void fetch_option()
{
             QSqlQuery query(*option_table);
             bool z = query.prepare("SELECT* FROM option_table WHERE id=:id");
             assert(z!=false);
            query.bindValue(":id",Quest_paper_count);
             z=query.exec();
             assert(z!=false);
             z =  query.next();
             assert(z!=false);
            qDebug() << ",,,,,,,,,,,,,,,,,Q paper"<<Quest_paper_count;
            for(int num=1;num<=NO_OF_OPTIONS;num++)
            {
                char q[20]={0};
                  sprintf(q,"option%d",num);
                  QString qs;
                  qs.sprintf(q);
                  int id = query.record().indexOf(qs);
                QString name = query.value(id).toString();
                qDebug() << name;
            }
             query.finish();


}
#endif
