#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QTime>
#include<QDebug>
#include<qtextedit.h>
#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/qprinter.h>
#include <QtGui/qpaintdevice.h>
#include <qpushbutton.h>
#include <QPalette>
#include<qfont.h>
#include<QFontComboBox>
#include<QStringListModel>
#include<QListView>
#include"common.h"


//textedit features
#define text_edit_font_size 15
#define text_edit_Shape 6

#define NOT_ANSWERED 'N'

void verify_answers_with_db();
bool create_store_answers_database();
void verify_answers();
void calculate_score();
void create_questions_button(int x, int y,int initial_val,int boundary_val,
                             QFrame * frame,int distanceX,int distanceY,
                             int size1,int size2,int no_of_button_in_one_line,int distance_between_button);


#define cal_opt_no(line_Number,k) ((line_Number*no_of_option)-(no_of_option-k))


QFrame *frame_resoning;
QFrame *frame_Data_Analysis;
QFrame *frame_General_Awareness;
QFrame *frame_english;

QString answer_file_path_thread = "/home/user/Desktop/database/correct_answer_table";
char* instruction_file_path_thread="/home/user/appandroid/instructions.txt";
QString options_file_DB = "/home/user/Desktop/database/option_table";
QString  quest_file_DB = "/home/user/Desktop/database/question_table";
QString  description_DB = "/home/user/Desktop/database/question_description_table";
QString  image_DB = "/home/user/Desktop/database/images_of_qp_db";
char* student_count;

QTime currentTime;
char answer;
int question_no;

int hour ;
int minute ;
 int second;
 bool stop_sec_timer;
 bool signal_next_clicked;
static answers  q[TOTAL_NO_QUESTIONS];
QTimer * timer ;
QTimer * timer_sec;

char *sptr;
int currect_answers,not_answered,wrong_answers;\
extern int question_paper_clicked;

QString entered_answer_path;

#ifdef mains_exam
//init boundary values
int section_1_init_val=0;
int section_1_boundary_val=Reasoning;
int section_2_init_val=Reasoning;
int section_2_boundary_val=Reasoning+Data_Analysis;
int section_3_init_val=Reasoning+Data_Analysis;
int section_3_boundary_val=Reasoning+Data_Analysis+General_Awareness;
int section_4_init_val=Reasoning+Data_Analysis+General_Awareness;
int section_4_boundary_val=Reasoning+Data_Analysis+General_Awareness+English_Language;
#endif


#ifdef prelims_exam
//init boundary values
int section_1_init_val=0;
int section_1_boundary_val=Reasoning;
int section_2_init_val=Reasoning;
int section_2_boundary_val=Reasoning+Data_Analysis;
int section_3_init_val=Reasoning+Data_Analysis;
int section_3_boundary_val=Reasoning+Data_Analysis+General_Awareness;
#endif


db_manage::db_manage(QString type_database)
{

           path=type_database;
           question_table = new QSqlDatabase();
           *question_table=  QSqlDatabase::addDatabase("QSQLITE");
           question_table->setDatabaseName(path);
            if (!question_table->open())
            {
                qDebug() << "Error: connection with database fail:question table";
             qDebug()<<question_table->lastError().text() ;
             assert(0);
             }
             query=new QSqlQuery(*question_table);
}


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//windows name and size setup
    this->setWindowTitle("EXAM APP");
    QDesktopWidget dw;
    int x=dw.width()*1;
    int y=dw.height()*1;
//    this->setFixedSize(x,y);
//    setWindowFlags(Qt::Window|Qt::WindowMaximizeButtonHint);


QStringList stringList;
stringList << "English" << "Hindi";
QStringListModel *mdl = new QStringListModel(stringList);
QFont comboFont("Arial",11,-1,true);
QListView *vw = new QListView;
vw->setFont(comboFont);
ui->fontComboBox->setModel(mdl);
ui->fontComboBox->setView(vw);
ui->radioButton_1->click();

int i,initial_val=0,boundary_val=0;
QFont font8;
font8.setPointSize(10);
font8.setBold(true);
font8.setWeight(50);
sptr=(char *)malloc(20);


frame_resoning=new QFrame(ui->frame_6);
frame_Data_Analysis=new QFrame(ui->frame_6);
frame_General_Awareness=new QFrame(ui->frame_6);
frame_english=new QFrame(ui->frame_6);

//set text edit
set_text_edit();

//reasoning
x=15,y=10;
initial_val=section_1_init_val;
boundary_val=section_1_boundary_val;
create_questions_button(15,10,initial_val,boundary_val,frame_resoning,
                        50,10,40,40,10,50);

//Data_Analysis
x=15,y=10;
initial_val=section_2_init_val;
boundary_val=section_2_boundary_val;
create_questions_button(15,10,initial_val,boundary_val,frame_Data_Analysis,
                        50,10,40,40,10,50);


//General_Awareness
x=15,y=10;
initial_val=section_3_init_val;
boundary_val=section_3_boundary_val;
create_questions_button(20,10,initial_val,boundary_val,frame_General_Awareness,
                        60,10,50,50,8,60);

//English_Language
x=15,y=10;
initial_val=section_4_init_val;
boundary_val=section_4_boundary_val;
create_questions_button(20,10,initial_val,boundary_val,frame_english,
                        60,10,50,50,8,60);

for(i=0;i<TOTAL_NO_QUESTIONS;i++)
connect(q[i].q_object, SIGNAL(clicked(bool)), this, SLOT(itwasclicked()));

free(sptr);

question_no=1;
timer = new QTimer(this);
connect(timer, SIGNAL(timeout()), this, SLOT(updateTime()));



timer_sec=new QTimer(this);
connect(timer_sec, SIGNAL(timeout()), this, SLOT(print_sec()));

run_timer();

//creating db for stroring answers and results
  bool m = create_store_answers_database();
  assert(m!=false);

MainWindow::openfile(1,0);


 MainWindow::openfile(2,0);
  Result_window =new Result();
//      Result_window->show();
//      QSlider sl;
//      sl.show();

   QObject::connect(this,SIGNAL(valueChanged(double,double,double,double)),Result_window,SLOT(setProgress(double,double,double,double)));


 q[0].q_object->click();
 ui->radioButton_1->click();
 ui->pushButton_5->click();

}

void MainWindow::run_timer()
{

    hour = TOTAL_MIN/60;
    minute = TOTAL_MIN%60;
   currentTime = QTime::currentTime();
    currentTime.setHMS(hour,minute,0);
    QString currentTimeText = currentTime.toString("hh:mm");
   minute--;
   ui->lcdNumber->display(currentTimeText);
   second=59;
   currentTimeText = currentTime.toString("00");
   ui->lcdNumber_2->display(currentTimeText);
   timer->start(1000*60);
   timer_sec->start(1000);

}

void MainWindow::set_text_edit()
{
    //text edit setup
    ui->textEdit->setStyleSheet("QTextEdit { background-color: rgb(255, 255, 255)}");;
    ui->textEdit->setFontPointSize(text_edit_font_size);
    ui->textEdit->setFrameStyle(text_edit_Shape);
}

void MainWindow::updateTime()
{


         currentTime.setHMS(hour,minute,0);
  QString     currentTimeText = currentTime.toString("hh:mm");
        ui->lcdNumber->display(currentTimeText);

        if(minute<=0 && hour>0)
        {
            hour--;
            minute=59;
        }
        else
        {
            if(hour==0 && (minute==0 || minute<0))
            {
                currentTimeText = currentTime.toString("00:00");
                ui->lcdNumber->display(currentTimeText);
                stop_sec_timer=true;
                QMessageBox::information(
                    this,
                    tr("expired"),
                    tr("your session expired!!") );

             int k= store_answers_to_file();
             print_attended_question(k);
             verify_answers();
             calculate_score();

             emit MainWindow::valueChanged( Reasoning_marks, data_analysis_marks, gk_marks, english_marks);
             //  QApplication::quit();
            }
        }
minute--;
}

void MainWindow::text_edit()
{

 delete ui;

}

MainWindow::~MainWindow()
{
    delete ui;

}

int MainWindow::openfile(int text_edit,int qa_no)
{
     char line[256]={0};

  int  lineNumber=qa_no+1;//qa_no starts with zero so linenumber+1

     switch(text_edit)
     {
     case 1:  //questions
     {
//fetching description
QString question = fetch_description_fromDB( lineNumber);
QByteArray ba;
ba=question.toLatin1();
strcpy(line,ba.data());
ui->textEdit->setText(QApplication::translate("MainWindow",line , 0));
ui->textEdit->append(QApplication::translate("MainWindow","\n", 0));

//fetching image
QString image="<html><body><img src=";
question = fetch_image_fromDB( lineNumber);

int len=question.length();
QString z = question.mid(len-1,1),z2="\n";
if(z==z2 )
{
question = question.mid(0,len-1);
}


if(question != "0" && question != "")
{
image=image+"\""+question+"\""+"/></body></html>";
ba=image.toLatin1();
strcpy(line,ba.data());
ui->textEdit->append(QApplication::translate("MainWindow",line , 0));
ui->textEdit->append(QApplication::translate("MainWindow","\n", 0));

}
//fetching questions
question = fetch_question_fromDB( lineNumber);
ba=question.toLatin1();
strcpy(line,ba.data());
ui->textEdit->append(QApplication::translate("MainWindow",line , 0));
ui->textEdit->append(QApplication::translate("MainWindow","\n", 0));

   break;
}
     case 2:
         {

db_manage * db_manage_option = new db_manage(options_file_DB);
QString option_str = "SELECT ";
for(int k=1;k<no_of_option;k++)
{
option_str = option_str+" option"+QString::number(cal_opt_no(lineNumber,k));
option_str = option_str+",";
}
option_str = option_str+" option"+QString::number(cal_opt_no(lineNumber,no_of_option));
option_str = option_str+" FROM option_table WHERE id=:id";
bool k=db_manage_option->query->prepare(option_str);
assert(k!=false);
db_manage_option->query->bindValue(":id",question_paper_clicked);
 k=db_manage_option->query->exec();
assert(k!=false);

          k =  db_manage_option->query->next();
          assert(k!=false);

           int init=cal_opt_no(lineNumber,1);
           int bound = cal_opt_no(lineNumber,no_of_option);
           int radio_button_count=1;
            for(int j=init;j<=bound;j++)
            {
                QString tem = "option";
                tem= tem+QString::number(j);
            int id = db_manage_option->query->record().indexOf(tem);
          QString question = db_manage_option->query->value(id).toString();
           QByteArray ba;
           ba=question.toLatin1();
           strcpy(line,ba.data());
           switch(radio_button_count)
           {
           case 1:ui->radioButton_1->setText(QApplication::translate("MainWindow",line , 0));break;
           case 2:ui->radioButton_2->setText(QApplication::translate("MainWindow",line , 0));break;
           case 3:ui->radioButton_3->setText(QApplication::translate("MainWindow",line , 0));break;
           case 4:ui->radioButton_4->setText(QApplication::translate("MainWindow",line , 0));break;
           case 5:ui->radioButton_5->setText(QApplication::translate("MainWindow",line , 0));break;
           }
           radio_button_count++;
        }
            delete db_manage_option;

         }
defualt: break;


     }

   return 0;
}




char * MainWindow::radio_button(char * arr ,char * ch)
{


          int  i=0;
if(ch[i] == '\n')
{
 arr[i]=ch[i];

}
else
{
             while(ch[i]!=';')
             {

                 arr[i]=ch[i];
                 i++;

             }
 }
             arr[i+1]='\0';
            ch=ch+i;

            return ch;
}


void MainWindow::on_radioButton_1_clicked()
{
    answer='a';

    qDebug()<<"answer is :"<<answer;

}

void MainWindow::on_radioButton_2_clicked()
{
    answer='b';
     qDebug()<<"answer is :"<<answer;

}

void MainWindow::on_radioButton_3_clicked()
{
    answer='c';
     qDebug()<<"answer is :"<<answer;

}

void MainWindow::on_radioButton_4_clicked()
{
    answer='d';
     qDebug()<<"answer is :"<<answer;
}

void MainWindow::on_pushButton_2_clicked()
{

 //   if(answer)
    {
    q[question_no-1].question_no=question_no;
    q[question_no-1].answer=answer;
    q[question_no-1].answer_saved=true;
    qDebug()<<"q and a is :"<<question_no<<answer;
    q[question_no-1].q_object->setStyleSheet("background-color: rgb(85, 170, 0);");
    QPalette palette;
     palette.setBrush(QPalette::ButtonText,Qt::white );
     q[question_no-1].q_object->setPalette(palette);
    answer=0;
    }
MainWindow::on_pushButton_4_clicked();
}




void MainWindow::on_pushButton_3_clicked()
{

MainWindow::someSlot() ;

}
void MainWindow::someSlot() {
  QMessageBox::StandardButton reply;

  reply = QMessageBox::question(this, "Test", "Quit?",
                                QMessageBox::Yes|QMessageBox::No);
  if (reply == QMessageBox::Yes) {
    qDebug() << "Yes was clicked";
       int k= store_answers_to_file();
       print_attended_question(k);
       verify_answers();
       calculate_score();
        emit MainWindow::valueChanged( Reasoning_marks, data_analysis_marks, gk_marks, english_marks);

    //QApplication::quit();
  } else {

    qDebug() << "Yes was *not* clicked";
  }
}

void MainWindow::itwasclicked()
{
//if(push_button_clicked)
//{
    qDebug() << "question clicked";
 QPalette palette;
  palette.setBrush(QPalette::ButtonText,Qt::white );
  //previous visited question for question no =0
if (question_no==0)
{
    if(  q[question_no].answer_saved == false && q[question_no].review_next == false)
    {//red
        q[question_no].q_object->setStyleSheet("background-color: rgb(255, 0, 0);");
    q[question_no].q_object->setPalette(palette);
    }
    else if(  q[question_no].answer_saved == true)
    {//green
        q[question_no].q_object->setStyleSheet("background-color: rgb(85, 170, 0);");
        q[question_no].q_object->setPalette(palette);
    }
        else if(q[question_no].review_next == true)
    {//blue
        q[question_no].q_object->setStyleSheet("background-color: rgb(85, 85, 255);");
        q[question_no].q_object->setPalette(palette);
    }
    else ;

}
 else  //previous visited question for question no >0
  {
    if(  q[question_no-1].answer_saved == false && q[question_no-1].review_next == false)
    {
      q[question_no-1].q_object->setStyleSheet("background-color: rgb(255, 0, 0);");
      q[question_no-1].q_object->setPalette(palette);
    }

    else if(  q[question_no-1].answer_saved == true)
    {
        q[question_no-1].q_object->setStyleSheet("background-color: rgb(85, 170, 0);");
        q[question_no-1].q_object->setPalette(palette);
    }
        else if(q[question_no-1].review_next == true)
    {
        q[question_no-1].q_object->setStyleSheet("background-color: rgb(85, 85, 255);");
        q[question_no-1].q_object->setPalette(palette);
    }
    else;
  }


    for(int i=0;i<TOTAL_NO_QUESTIONS;i++)
    {

  // bool checked =false;
   //q[i].q_object->clicked(checked);
   if(q[i].q_object->isChecked())
   {
      // FILE *fptr=NULL;
       question_no=i+1;

    q[i].q_object->setStyleSheet("background-color: rgb(170, 170, 127);");
    q[i].q_object->setPalette(palette);

q[i].q_object->setChecked(false);
       // fptr = fopen("/home/user/examapp1/question.txt", "r");
         MainWindow::openfile(1,i);
       //  fptr = fopen("/home/user/examapp1/options.txt", "r");
          MainWindow::openfile(2,i);
     //   qDebug()<<"question_no is:"<<question_no;

         switch(q[i].answer)
         {
         case 'a': ui->radioButton_1->click();break;
          case 'b': ui->radioButton_2->click();break;
               case 'c': ui->radioButton_3->click();break;
           case 'd': ui->radioButton_4->click();break;
              case 'e': ui->radioButton_5->click();break;
         default: ui->radioButton_1->click();break;
         }

   }

    }
//}
}


void MainWindow::print_sec()
{

char *string=(char*)malloc(4);


//QString     currentTimeText = currentTime.toString(second);
//if(second >0)
{
    sprintf(string,"%d ",second);
ui->lcdNumber_2->display(string);
}

 if (second==0 && stop_sec_timer==false) // countdown has finished
   {
second =59;
sprintf(string,"%d ",second);
ui->lcdNumber_2->display(string);
   }
   else if(second<0 || stop_sec_timer==true)
   {
       QString     currentTimeText = currentTime.toString("00");
       ui->lcdNumber_2->display(currentTimeText);


   }

  second--;
free(string);
}

void MainWindow::on_pushButton_4_clicked()
{
    signal_next_clicked=true;

    ui->radioButton_1->click();

   if(question_no<TOTAL_NO_QUESTIONS)
    {

    if(question_no==Reasoning)
    {
    ui->pushButton_7->click();
    }
   else if(question_no==Reasoning+Data_Analysis)
    {
        ui->pushButton_8->click();

    }
  else  if(question_no==Reasoning+Data_Analysis+General_Awareness)
    {
        ui->pushButton_6->click();

    }
    else
   q[question_no].q_object->click();
    qDebug()<<"question_no"<<question_no;
   }

else
   {
 ui->pushButton_5->click();
question_no=0;
q[question_no].q_object->click();

   }

   for(int i=0;i<TOTAL_NO_QUESTIONS;i++)
   {


  if(q[i].q_object->isChecked() )
  {

  question_no=i+1;
  qDebug()<<"on_pushButton_4_clicked"<<question_no;
  }

   }

}
 answers::~answers()
 {

 }
 db_manage::~db_manage()
 {

     delete query;
     delete question_table;
 }


void MainWindow::print_attended_question(int attended_question)
{
    char ch[200]={0};
    timer->stop();
   //timer_q->start(100);
   timer_sec->stop();
    sprintf(ch,"attended question %d \nsection1 %d \nsection2 %d \nsection3 %d \nsection4 %d ",
            attended_question,
            attended_section_1_question,attended_section_2_question,
            attended_section_3_question,attended_section_4_question);
    QMessageBox::information(
        this,
        tr("attended question"),
        tr(ch) );

}
bool create_store_answers_database()
{
    QDir dir;
    entered_answer_path=dir.currentPath()+"/entered_answers";
 db_manage *   answers_table = new db_manage(entered_answer_path);


  QString quest = "create table IF NOT EXISTS  entered_answer_table(id integer primary key";
  for(int i=1;i<=TOTAL_NO_QUESTIONS;i++)
  {
 QString quest_ = ",answer"+QString::number(i)+"  varchar(300)" ;
 quest = quest + quest_;
  }
  quest = quest + ", database_filled bool)";
  qDebug()<<quest;
  bool  k=answers_table->query->exec(quest);
  assert(k!=false);

 k = answers_table->query->exec("SELECT MAX(id) FROM entered_answer_table");
 assert(k!=false);
  answers_table->query->next();
 int max_id = answers_table->query->value(0).toInt();

if(question_paper_clicked>max_id)
{
  for(int i=max_id;i<question_paper_clicked;i++)
{


  bool m =  answers_table->query->exec("INSERT  INTO  entered_answer_table(answer1,database_filled) VALUES(0,0)");
   assert(m!=false);


}
}
delete answers_table;
return true;
}

bool answer_saved;

 char *ALL_answers;
int MainWindow::store_answers_to_file()
{
    int attended_question=0;

//if(!answer_saved)
{

    ALL_answers=(char*)malloc(TOTAL_NO_QUESTIONS);

    int j;
    int answer_section_init_val[NO_OF_SECTIONS];
    int answer_section_bound_val[NO_OF_SECTIONS];

    answer_section_init_val[0]=section_1_init_val;\
    answer_section_init_val[1]=section_2_init_val;
    answer_section_init_val[2]=section_3_init_val;
    answer_section_init_val[3]=section_4_init_val;

    answer_section_bound_val[0]=section_1_boundary_val;
    answer_section_bound_val[1]=section_2_boundary_val;
    answer_section_bound_val[2]=section_3_boundary_val;
    answer_section_bound_val[3]=section_4_boundary_val;

    for(j = 0;j < NO_OF_SECTIONS;j++)
    {
        int init=answer_section_init_val[j];
        int boundary=answer_section_bound_val[j];
        int i;
        for(i=init;i<boundary;i++)
        {
        char c=q[i].answer;
        if(c !=0)
        {
            attended_question++;
            if(init >= section_1_init_val && init < section_2_init_val)
            attended_section_1_question ++;
            else if (init >= section_2_init_val && init < section_3_init_val)
            attended_section_2_question ++;
            else if (init >= section_3_init_val && init < section_4_init_val)
            attended_section_3_question ++;
            else if (init >= section_4_init_val && init<TOTAL_NO_QUESTIONS )
            attended_section_4_question ++;
     ALL_answers[i]=c;
        }
        else
        ALL_answers[i]=NOT_ANSWERED;


        }
    }


  answer_saved=true;
//  bool m = create_store_answers_database();
//  assert(m!=false);
db_manage * answers_table = new db_manage(entered_answer_path);;

QSqlQuery query_answers (*answers_table);

QString query_str;
query_str=  "UPDATE entered_answer_table SET  ";
for(int Quest_count =1;Quest_count<=TOTAL_NO_QUESTIONS;Quest_count++)
{

   query_str =query_str+"answer"+QString::number(Quest_count)+" = \""+ALL_answers[Quest_count-1] +"\" ";
   if(Quest_count<TOTAL_NO_QUESTIONS)
   query_str = query_str+",";
}

query_str = query_str+"WHERE id=:id";
qDebug()<<query_str;
    bool k = query_answers.prepare(query_str);
    qDebug()<<query_answers.lastError().text();
    assert(k!=false);
    query_answers.bindValue(":id", question_paper_clicked);
     k =  query_answers.exec();
    qDebug()<<"--------->"<<k+"   "<<query_answers.lastError().text() ;
 assert(k!=false);

 k=query_answers.prepare("UPDATE entered_answer_table SET database_filled =:val WHERE id=:id");
qDebug()<<"--------->"<<k+"   "<<query_answers.lastError().text() ;
assert(k!=false);
query_answers.bindValue(":val",true);
query_answers.bindValue(":id",question_paper_clicked);

k=query_answers.exec();
qDebug()<<"--------->"<<k+"   "<<query_answers.lastError().text() ;
assert(k!=false);
delete answers_table;

return attended_question;

}
}
void verify_answers()
{

db_manage* correct_answer_table =new db_manage(answer_file_path_thread);
bool k=correct_answer_table->query->prepare("SELECT* FROM answer_table WHERE rowid =:x");
qDebug()<<"--------->"<<k+"   "<<correct_answer_table->query->lastError().text() ;
assert(k!=false);
int init=0;
char c[3]={0};
char * line1;
line1=&c[0];
correct_answer_table->query->bindValue(":x",question_paper_clicked);
k=correct_answer_table->query->exec();
qDebug()<<"--------->"<<k+"   "<<correct_answer_table->query->lastError().text() ;
assert(k!=false);
k = correct_answer_table->query->next();
assert(k!=false);

for(int i=0;i<TOTAL_NO_QUESTIONS;i++)
{

    QString answer;
    answer = "answer"+QString::number(i+1);
    int idName = correct_answer_table->query->record().indexOf(answer);
    answer = correct_answer_table->query->value(idName).toString();
    qDebug()<<answer;

     QByteArray ba = answer.toLatin1();
    line1 = ba.data();


            if(init >= section_1_init_val && init < section_2_init_val)
            {
            if(line1[0]==ALL_answers[init])
             correct_reasoning++;
            else if(ALL_answers[init] == NOT_ANSWERED)
                not_answered_resoning++;
            else
               wrong_answered_resoning++ ;

            }
            else if (init >= section_2_init_val && init < section_3_init_val)
            {
            if(line1[0]==ALL_answers[init])
                correct_data_analysis++;

            else if(ALL_answers[init] == NOT_ANSWERED)
                not_answered_data_analysis++;
            else
               wrong_answered_data_analysis++ ;
            }
            else if (init >= section_3_init_val && init < section_4_init_val)
            {
            if(line1[0]==ALL_answers[init])
                correct_GK++;

            else if(ALL_answers[init] == NOT_ANSWERED)
                not_answered_GK++;
            else
               wrong_answered_GK++ ;
            }

            else if (init >= section_4_init_val && init<TOTAL_NO_QUESTIONS)
            {
           if(line1[0]==ALL_answers[init])
               correct_english++;

           else if(ALL_answers[init] == NOT_ANSWERED)
               not_answered_english++;
           else
              wrong_answered_english++ ;
            }


            init++;
        }

        currect_answers=correct_reasoning+correct_data_analysis+
                        correct_GK+correct_english;
        not_answered=not_answered_resoning+not_answered_data_analysis+
                      not_answered_GK+not_answered_english;
        wrong_answers=wrong_answered_resoning+wrong_answered_data_analysis+
                       wrong_answered_GK+wrong_answered_english;

delete correct_answer_table;

        free(ALL_answers);
}

void calculate_score()
{
    Reasoning_marks=cal_score(correct_reasoning,wrong_answered_resoning);
    data_analysis_marks  =cal_score(correct_data_analysis,wrong_answered_data_analysis);
    gk_marks =cal_score(correct_GK,wrong_answered_GK);
    english_marks =cal_score(correct_english,wrong_answered_english);
//    overall_score = cal_overall_score(Reasoning_marks,data_analysis_marks,
//                                      gk_marks,english_marks);

overall_score = Reasoning_marks+data_analysis_marks+gk_marks+english_marks;
}

void MainWindow::on_pushButton_13_clicked()
{
    //review and next
    if( q[question_no-1].answer==0)
    {
    q[question_no-1].answer=0;
    q[question_no-1].answer_saved=false;
    q[question_no-1].q_object->setStyleSheet("background-color: rgb(85, 85, 255);");
    QPalette palette;
     palette.setBrush(QPalette::ButtonText,Qt::white );
     q[question_no-1].q_object->setPalette(palette);
    answer=0;
      q[question_no-1].review_next=true;
     }
    MainWindow::on_pushButton_4_clicked();

}

void MainWindow::on_pushButton_11_clicked()
{
    //clear response
    if( q[question_no-1].answer_saved ||  q[question_no-1].review_next== true)
    {
    q[question_no-1].answer=0;
    q[question_no-1].answer_saved=false;
    q[question_no-1].review_next=false;
//    q[question_no-1].q_object->setStyleSheet("background-color: rgb(255, 0, 0);");
//    QPalette palette;
//     palette.setBrush(QPalette::ButtonText,Qt::white );
    // q[question_no-1].q_object->setPalette(palette);
    answer=0;
//    MainWindow::on_pushButton_4_clicked();

    }
}

void MainWindow::on_radioButton_5_clicked()
{
    answer='e';
     qDebug()<<"answer is :"<<answer;
}




void MainWindow::on_pushButton_clicked()
{
    timer->stop();
   timer_sec->stop();
   QMessageBox::StandardButton resume;

   resume = QMessageBox::warning(this, "Paused", "Resume",
                                 QMessageBox::Ok);
   if (resume == QMessageBox::Close) {

        int k= store_answers_to_file();
        print_attended_question(k);
        verify_answers();
        calculate_score();

         emit MainWindow::valueChanged( Reasoning_marks, data_analysis_marks, gk_marks, english_marks);
     //QApplication::quit();
   }
   else

   {
     timer->start();
    timer_sec->start();
   }


}


void MainWindow::on_pushButton_5_clicked()
{


    frame_resoning->show();
    frame_Data_Analysis->hide();
    frame_General_Awareness->hide();
    frame_english->hide();

    q[0].q_object->click();
    ui->radioButton_1->click();

    ui->pushButton_5->setStyleSheet("background-color: rgb(85, 170, 0);");
    ui->pushButton_6->setStyleSheet("background-color: rgb(170, 170, 255);");
    ui->pushButton_7->setStyleSheet("background-color: rgb(170, 170, 255);");
    ui->pushButton_8->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->label_4->setText("you are seeing Reasoning sections");
}

void MainWindow::on_pushButton_7_clicked()
{

    frame_resoning->hide();
    frame_Data_Analysis->show();
    frame_General_Awareness->hide();
    frame_english->hide();

    q[Reasoning].q_object->click();
    ui->radioButton_1->click();

    ui->pushButton_7->setStyleSheet("background-color: rgb(85, 170, 0);");
     ui->pushButton_5->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->pushButton_6->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->pushButton_8->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->label_4->setText("you are seeing Data Analysis sections");
}

void MainWindow::on_pushButton_8_clicked()
{


    frame_resoning->hide();
    frame_Data_Analysis->hide();
    frame_General_Awareness->show();
    frame_english->hide();

    q[Reasoning+Data_Analysis].q_object->click();
    ui->radioButton_1->click();

     ui->pushButton_8->setStyleSheet("background-color: rgb(85, 170, 0);");
     ui->pushButton_5->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->pushButton_7->setStyleSheet("background-color: rgb(170, 170, 255);");
     ui->pushButton_6->setStyleSheet("background-color: rgb(170, 170, 255);");

 ui->label_4->setText("you are seeing General Awareness sections");
}
void MainWindow::on_pushButton_6_clicked()
{


    frame_resoning->hide();
    frame_Data_Analysis->hide();
    frame_General_Awareness->hide();
    frame_english->show();

    q[Reasoning+Data_Analysis+General_Awareness].q_object->click();
    ui->radioButton_1->click();


    ui->pushButton_6->setStyleSheet("background-color: rgb(85, 170, 0);");
    ui->pushButton_5->setStyleSheet("background-color: rgb(170, 170, 255);");
    ui->pushButton_7->setStyleSheet("background-color: rgb(170, 170, 255);");
    ui->pushButton_8->setStyleSheet("background-color: rgb(170, 170, 255);");

 ui->label_4->setText("you are seeing English Language sections");
}
void create_questions_button(int x, int y,int initial_val,int boundary_val,
                             QFrame * frame,int distanceX,int distanceY,
                             int size1,int size2,int no_of_button_in_one_line,int distance_between_button)
{
    int i,x2=117,y2=22;
    for( i=initial_val;i<boundary_val;i++)
    {

    q[i].q_object = new QToolButton(frame);
    q[i].q_object->setCheckable(true);

    //allignement
    if(i%no_of_button_in_one_line == 0  && i>initial_val)
    {
        x=x+distanceX;y=distanceY;
    }
    q[i].q_object->setGeometry(QRect(x,y , x2, y2));
    q[i].q_object->setFixedSize(size1,size2);
    y=y+distance_between_button;

        sprintf(sptr,"%d",i+1);
         q[i].q_object->setText(sptr);

    }

}



   QString fetch_question_fromDB(int lineNumber)
    {
      db_manage *db_manage_question  =  new db_manage(quest_file_DB);
        QString temp = "SELECT question"+QString::number(lineNumber)+" FROM questions where id=:id";
      if((db_manage_question->query->prepare(temp))==false)
      {
      qDebug()<<"error :"<<db_manage_question->query->lastError();
      assert(0);
      }
      db_manage_question->query->bindValue(":id",question_paper_clicked);
      if( db_manage_question->query->exec() ==false)
      {
      qDebug()<<db_manage_question->query->lastError();
      assert(0);
      }
      //
      if(db_manage_question->query->next() == false )
      {
      qDebug()<<db_manage_question->query->lastError();
      assert(0);
      }
      QString qs;
      qs.sprintf("question%d",lineNumber);
      int id = db_manage_question->query->record().indexOf(qs);
      qs = db_manage_question->query->value(id).toString();
      delete db_manage_question;
      return qs;
    }

   QString fetch_description_fromDB(int lineNumber)
    {
        db_manage *db_manage_description  =  new db_manage(description_DB);
        QString temp = "SELECT description"+QString::number(lineNumber)+" FROM description_table where id=:id";
      if((db_manage_description->query->prepare(temp))==false)
      {
      qDebug()<<"error :"<<db_manage_description->query->lastError();
      assert(0);
      }
      db_manage_description->query->bindValue(":id",question_paper_clicked);
      if( db_manage_description->query->exec() ==false)
      {
      qDebug()<<db_manage_description->query->lastError();
      assert(0);
      }
      //
      if(db_manage_description->query->next() == false )
      {
      qDebug()<<db_manage_description->query->lastError();
      assert(0);
      }
      QString qs;
      qs.sprintf("description%d",lineNumber);
      int id = db_manage_description->query->record().indexOf(qs);
      qs = db_manage_description->query->value(id).toString();
     delete db_manage_description;
      return qs;
    }


   QString fetch_image_fromDB(int lineNumber)
    {
        db_manage *db_manage_image_table =  new db_manage(image_DB);
        QString temp = "SELECT image"+QString::number(lineNumber)+" FROM image_table where id=:id";
      if((db_manage_image_table->query->prepare(temp))==false)
      {
      qDebug()<<"error :"<<db_manage_image_table->query->lastError();
      assert(0);
      }
      db_manage_image_table->query->bindValue(":id",question_paper_clicked);
      if( db_manage_image_table->query->exec() ==false)
      {
      qDebug()<<db_manage_image_table->query->lastError();
      assert(0);
      }
      //
      if(db_manage_image_table->query->next() == false )
      {
      qDebug()<<db_manage_image_table->query->lastError();
      assert(0);
      }
      QString qs;
      qs.sprintf("image%d",lineNumber);
      int id = db_manage_image_table->query->record().indexOf(qs);
      qs = db_manage_image_table->query->value(id).toString();
      delete db_manage_image_table;
      return qs;
    }


