#include "mainwindow.h"
#include <QApplication>
#include<assert.h>
#include<qtableview.h>

void add_questions(int question_paper_clicked,QString path);
void create_table(QString path_1 ,int select);


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
   MainWindow w;
    QString path="/home/user/Desktop/database/question_table";
    create_table(path,1);
  add_questions(1,path);



    QSqlDatabase *question_table;
  QSqlDatabase  question_table_=QSqlDatabase::addDatabase("QSQLITE");
  question_table=& question_table_;
  question_table->setDatabaseName(path);
    if (!question_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }

    QSqlQuery query(*question_table);
    query.exec("SELECT* FROM questions");
    QSqlQueryModel *model = new QSqlQueryModel();
    model->setQuery(query);

    QTableView *view = new QTableView(&w);
    view->setModel(model);

    w.setCentralWidget(view);

 w.show();
    return a.exec();
}

void create_table(QString path_1 ,int select)
{
    QString path=path_1;
    QSqlDatabase *question_table;
  QSqlDatabase  question_table_=QSqlDatabase::addDatabase("QSQLITE");
  question_table=& question_table_;
  question_table->setDatabaseName(path);
    if (!question_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
    QSqlQuery query_questions(*question_table);
    QString quest = "create table IF NOT EXISTS questions(id integer primary key";
    for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
    {
   QString quest_ = ",question"+QString::number(i)+"  varchar(300)" ;
   quest = quest + quest_;
    }
    quest = quest +")";
    qDebug()<<quest;
  bool  k=query_questions.exec(quest);
  assert(k!=false);
for(int j=1;j<=TOTAL_NO_OF_Q_PAPER;j++)
{
   // for(int i=1;i<=TOTAL_NO_OF_QUESTIONS;i++)
    //{
//     QString q = "INSERT INTO questions(question"+QString::number(i)+") VALUES(0) WHERE id=:i ";
//     bool  k=query_questions.prepare(q);
//     query_questions.bindValue(":id",j);
     query_questions.exec("INSERT INTO questions(question1) VALUES(NULL)");
     assert(k!=false);

    //}
}
query_questions.finish();
}


void add_questions(int question_paper_clicked,QString path)
{
    for( int i=1;i<=3;i++)
 {
  QSqlDatabase *question_table;
  QSqlDatabase  question_table_=QSqlDatabase::addDatabase("QSQLITE");
  question_table=& question_table_;
  question_table->setDatabaseName(path);
    if (!question_table->open())
    {
       qDebug() << "Error: connection with database fail:question table";
    }
     QSqlQuery query_questions(*question_table);
    FILE *question_fptr;
 char* ch,*ch2;

  ch=(char*)malloc(256);
  ch2=(char*)malloc(18);
    char line[256]={0};
    int Quest_count=1;
    strcpy(ch,quest_file_path_thread);

    sprintf(ch2,"%d.txt\0",i);
    strcat(ch,ch2);
    question_fptr=fopen(ch,"r");
    free(ch);
    free(ch2);
    if(question_fptr== NULL)
    {
        qDebug()<<"cant open question file thus exiting ";
       exit(1);
    }

      while ((fgets(line, sizeof line, question_fptr) != NULL)&& (Quest_count<=200)) /* read a line */
    {
        QString qstn,query_str;
        qstn.sprintf(line);
       query_str = "UPDATE questions SET question"+QString::number(Quest_count)+" = \""+qstn +"\" WHERE id=:id";
      // query_str = "INSERT OR  REPLACE INTO questions(question"+QString::number(Quest_count)+") VALUES(:question)";
        bool k =  query_questions.prepare(query_str);
        qDebug()<<query_questions.lastError().text();
        assert(k!=false);
        query_questions.bindValue(":id", i);
         k =  query_questions.exec();
        qDebug()<<"--------->"<<k+"   "<<query_questions.lastError().text() ;
     assert(k!=false);
     Quest_count++;
     }



      fclose(question_fptr);



}


}
#if 0
void fetch_record()
{
    QSqlDatabase *question;
    QSqlDatabase  question_=QSqlDatabase::addDatabase("QSQLITE");
    question=& question_;
    question->setDatabaseName(path);
     if (!question->open())
     {
        qDebug() << "Error: connection with database fail:question table";
     }
     QSqlQuery query(*question);
     bool z = query.prepare("SELECT* FROM questions WHERE id=:id");
     assert(z!=false);
    query.bindValue(":id",i);
     z=query.exec();
     assert(z!=false);
     z =  query.next();
     assert(z!=false);
    qDebug() << ",,,,,,,,,,,,,,,,,Q paper"<<i;
    for(int num=1;num<=Quest_count;num++)
    {
        char q[20]={0};
          sprintf(q,"question%d",num);
          QString qs;
          qs.sprintf(q);
          int id = query.record().indexOf(qs);
        QString name = query.value(id).toString();
        qDebug() << name;
    }
    query_questions.finish();
    query.finish();
    qDebug() << ",,,,,,,,,,,,,,,,,,,,,,,,,,,";
}
#endif
